package com.SafiArian.CRUD;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SafiArianCrudApplicationTests {

	@Test
	void contextLoads() {
	}

}
